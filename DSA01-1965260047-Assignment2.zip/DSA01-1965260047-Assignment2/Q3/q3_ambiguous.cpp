// Intentionally ambiguous; expected compilation failure.
double charge(double w){return w*40;} double charge(double w,bool e){return w*40+(e?50:0);} double charge(double w,bool e=false,bool i=false){(void)e;(void)i;return w*40;} int main(){return (int)charge(2.0);}
