#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
class Time {
    int h,m,s;
public:
    Time(int hh=0,int mm=0,int ss=0):h(hh),m(mm),s(ss){}
    Time& operator++(){if(++s==60){s=0;if(++m==60){m=0;++h;}}return *this;}
    Time operator++(int){Time old=*this;++(*this);return old;}
    bool operator==(const Time& o)const{return h==o.h&&m==o.m&&s==o.s;}
    bool operator<(const Time& o)const{return h!=o.h?h<o.h:(m!=o.m?m<o.m:s<o.s);}
    friend std::ostream& operator<<(std::ostream& os,const Time& t){return os<<t.h<<':'<<std::setw(2)<<std::setfill('0')<<t.m<<':'<<std::setw(2)<<t.s<<std::setfill(' ');}
};
class Playlist {
    std::vector<std::string> tracks;
public:
    void add(const std::string& s){tracks.push_back(s);}
    std::string& operator[](std::size_t i){return tracks.at(i);}
    const std::string& operator[](std::size_t i)const{return tracks.at(i);}
};
int main(){Time t(1,2,58);std::cout<<t++<<' '<<++t<<'\n';Playlist p;p.add("Track One");p.add("Track Two");std::cout<<p[1]<<'\n';}
