#include <iostream>
#include <memory>
#include <string>
struct Address{std::string city;int pin;Address(std::string c,int p):city(std::move(c)),pin(p){}std::string str()const{return city+"-"+std::to_string(pin);}};struct Student{std::string name;std::unique_ptr<Address> home;Student(std::string n,std::string c,int p):name(std::move(n)),home(std::make_unique<Address>(std::move(c),p)){}Student(const Student& o):name(o.name),home(std::make_unique<Address>(*o.home)){}Student& operator=(const Student&o){if(this!=&o){name=o.name;home=std::make_unique<Address>(*o.home);}return *this;}void print()const{std::cout<<name<<' '<<home->str()<<'\n';}};int main(){Student a("Kavya","Salem",636001),b=a;b.print();a.print();}
