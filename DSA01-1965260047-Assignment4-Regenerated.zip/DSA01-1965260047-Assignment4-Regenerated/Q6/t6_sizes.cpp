#include <iostream>
struct Plain{double daily;int rented;};struct Polymorphic{double daily;int rented;virtual ~Polymorphic()=default;virtual double charge(double x)const=0;};struct Bike:Polymorphic{double charge(double x)const override{return daily+x*.5;}};int main(){std::cout<<"Plain size="<<sizeof(Plain)<<" bytes\nPolymorphic size="<<sizeof(Polymorphic)<<" bytes\n";}
