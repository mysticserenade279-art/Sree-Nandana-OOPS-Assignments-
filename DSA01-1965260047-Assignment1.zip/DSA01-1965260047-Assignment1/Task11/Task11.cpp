#include <iostream>
#include <iomanip>

enum class Zone { Inner, Middle, Outer };
constexpr long long FARES[] = {1000, 2000, 3000};
constexpr long long MIN_BALANCE = 5000;

class SmartCard {
private:
    long long balancePaise;
public:
    explicit SmartCard(long long initialPaise) : balancePaise(initialPaise) {}

    bool pay(long long farePaise) {
        if (farePaise < 0 || balancePaise - farePaise < MIN_BALANCE)
            return false;
        balancePaise -= farePaise;
        return true;
    }

    long long balance() const { return balancePaise; }
};

long long calculateFare(Zone zone, int hour) {
    const int index = static_cast<int>(zone);
    if (index < 0 || index > 2 || hour < 0 || hour > 23) return -1;
    long long fare = FARES[index];
    const bool peak = (hour >= 8 && hour < 10) || (hour >= 17 && hour < 20);
    if (peak) fare += fare * 20 / 100;
    return fare;
}

int main() {
    SmartCard card(10000);
    const long long fare = calculateFare(Zone::Middle, 9);

    if (fare >= 0 && card.pay(fare))
        std::cout << "Journey accepted\n";
    else
        std::cout << "Journey denied\n";

    std::cout << "Remaining balance: Rs " << std::fixed
              << std::setprecision(2) << card.balance() / 100.0 << '\n';
}
