# Assignment 2 — C++ Functions and OOP

**Name:** SREE NANDANA.K  
**Register Number:** 1965260047  
**Course Code:** DSA0101  
**Course:** C++ Programming

## Contents
Q1 parameter passing and concession; Q2 return references and dangling reference; Q3 overloads; Q4 SavingsAccount history; Q5 static members and ticket objects; Q6 friend functions and timing; Q7 shifting array versus circular buffer.

## Compile and run
Use a C++17 compiler. Check compiler version with `g++ --version`. Compile each source separately because each has its own `main()`. Example:
```bash
g++ -std=c++17 -Wall -Wextra Q1/q1_complete.cpp -o q1
./q1
```
On Windows run `q1.exe`.

## Intentional demonstrations
- `Q2/q2_dangling.cpp` intentionally returns a reference to a local variable. This is unsafe and has undefined behavior; do not rely on its output.
- `Q3/q3_ambiguous.cpp` intentionally fails compilation to show the overload ambiguity. Use `Q3/q3.cpp` for the corrected program.
- `Q6/q6_timing.cpp` and `Q7/q7_bench.cpp` produce machine-dependent timing measurements. Run them yourself and fill your report with your own results.

## Evidence
Capture your own compiler/terminal output screenshots and add them to the relevant Q folders. Keep your written report with explanations, predicted outputs, complexity analysis, and measured timing tables. Sample output files are examples only, not proof of your own execution.

## Progressive commits
Make meaningful commits question by question, for example `git add Q1 && git commit -m "Complete Q1 parameter passing"`, then continue through Q7.
