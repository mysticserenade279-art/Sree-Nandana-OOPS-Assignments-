#include <iostream>
#include <string>
struct Address{std::string city;int pin;Address(std::string c,int p):city(std::move(c)),pin(p){std::cout<<"Address ";}~Address(){std::cout<<"~Address ";}};
struct Course{std::string title;Course(std::string t):title(std::move(t)){std::cout<<"Course ";}~Course(){std::cout<<"~Course ";}};
struct Person{std::string name;Address address;Person(std::string n,std::string c,int p):name(std::move(n)),address(std::move(c),p){std::cout<<"Person ";}virtual ~Person(){std::cout<<"~Person ";}};
struct Student:virtual Person{Course course;Student(std::string n,std::string c,int p,std::string cr):Person(n,c,p),course(std::move(cr)){std::cout<<"Student ";}~Student(){std::cout<<"~Student ";}};
struct Staff:virtual Person{double salary;Staff(std::string n,std::string c,int p,double s):Person(n,c,p),salary(s){std::cout<<"Staff ";}~Staff(){std::cout<<"~Staff ";}};
struct TA:Student,Staff{TA():Person("Arun","Chennai",600001),Student("Arun","Chennai",600001,"DSA"),Staff("Arun","Chennai",600001,18000){std::cout<<"TA ";}~TA(){std::cout<<"~TA ";}};
int main(){{TA t;std::cout<<"| ";}std::cout<<'\n';}
