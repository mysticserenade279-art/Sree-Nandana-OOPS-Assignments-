#include <iostream>
#include <iomanip>

enum class Zone { Inner, Middle, Outer };
constexpr long long BASE_PAISE[] = {1000, 2000, 3000};
constexpr int PEAK_SURCHARGE_PERCENT = 20;
constexpr long long MIN_BALANCE_PAISE = 5000;

bool inPeakHour(int hour) {
    return (hour >= 8 && hour < 10) || (hour >= 17 && hour < 20);
}

long long fare(Zone zone, bool peak) {
    long long amount = 0;
    switch (zone) {
        case Zone::Inner: amount = BASE_PAISE[0]; break;
        case Zone::Middle: amount = BASE_PAISE[1]; break;
        case Zone::Outer: amount = BASE_PAISE[2]; break;
    }
    if (peak) amount += amount * PEAK_SURCHARGE_PERCENT / 100;
    return amount;
}

bool canTravel(long long balance, long long cost) {
    return cost >= 0 && balance - cost >= MIN_BALANCE_PAISE;
}

int main() {
    long long balance = 10000;
    struct Trip { Zone zone; int hour; };
    const Trip trips[] = {
        {Zone::Inner, 7}, {Zone::Outer, 9}, {Zone::Middle, 12}
    };

    for (const Trip& trip : trips) {
        const long long cost = fare(trip.zone, inPeakHour(trip.hour));
        if (canTravel(balance, cost)) {
            balance -= cost;
            std::cout << "Fare Rs " << cost / 100 << '.'
                      << std::setw(2) << std::setfill('0') << cost % 100
                      << std::setfill(' ');
        } else {
            std::cout << "Denied (low balance)";
        }
        std::cout << " balance Rs " << balance / 100 << '\n';
    }
}
