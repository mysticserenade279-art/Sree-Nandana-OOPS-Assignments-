#include <chrono>
#include <iostream>
constexpr int CAP=1000;
class Shift{long long t[CAP];int n=0;public:void add(long long x){if(n==CAP){for(int i=1;i<CAP;++i)t[i-1]=t[i];n=CAP-1;}t[n++]=x;}long long last()const{return t[n-1];}long long oldest()const{return t[0];}};
class Circular{long long t[CAP];int start=0,n=0;public:void add(long long x){if(n<CAP){t[(start+n)%CAP]=x;++n;}else{t[start]=x;start=(start+1)%CAP;}}long long last()const{return t[(start+n-1)%CAP];}long long oldest()const{return t[start];}};
template<class H>double run(H&h,int n,long long&check){auto s=std::chrono::steady_clock::now();for(int i=1;i<=n;++i)h.add(i);auto e=std::chrono::steady_clock::now();check=h.last()+h.oldest();return std::chrono::duration<double,std::milli>(e-s).count();}
int main(){for(int n:{10000,100000,1000000}){Shift a;Circular b;long long x,y;double ta=run(a,n,x),tb=run(b,n,y);std::cout<<"n="<<n<<" shifting="<<ta<<" ms circular="<<tb<<" ms same result="<<std::boolalpha<<(x==y)<<'\n';}}
