#include <chrono>
#include <iostream>
class Time{int h,m;public:Time(int a,int b):h(a),m(b){}int getH()const{return h;}int getM()const{return m;}int minutesTo(const Time&b)const{int x=h*60+m,y=b.h*60+b.m;return x>y?x-y:y-x;}friend int inl(const Time&,const Time&);friend int noInl(const Time&,const Time&);};
inline int inl(const Time&a,const Time&b){int x=a.h*60+a.m,y=b.h*60+b.m;return x>y?x-y:y-x;}
#if defined(__GNUC__) || defined(__clang__)
__attribute__((noinline))
#endif
int noInl(const Time&a,const Time&b){int x=a.h*60+a.m,y=b.h*60+b.m;return x>y?x-y:y-x;}
int getters(const Time&a,const Time&b){int x=a.getH()*60+a.getM(),y=b.getH()*60+b.getM();return x>y?x-y:y-x;}
template<class F>double measure(F f){auto s=std::chrono::steady_clock::now();long long sum=0;for(int i=0;i<10000000;++i)sum+=f(i);auto e=std::chrono::steady_clock::now();volatile long long sink=sum;(void)sink;return std::chrono::duration<double,std::milli>(e-s).count();}
int main(){Time a(9,45);std::cout<<"inline: "<<measure([&](int i){return inl(a,Time(i%24,i%60));})<<" ms\n"<<"noinline: "<<measure([&](int i){return noInl(a,Time(i%24,i%60));})<<" ms\n"<<"member: "<<measure([&](int i){return a.minutesTo(Time(i%24,i%60));})<<" ms\n"<<"getters: "<<measure([&](int i){return getters(a,Time(i%24,i%60));})<<" ms\n";}
