#include <iostream>
#include <memory>
#include <string>
#include <vector>
class Account{protected:std::string owner_;double balance_;public:Account(std::string o,double b):owner_(std::move(o)),balance_(b){}virtual ~Account()=default;virtual double rate()const{return 3.5;}virtual std::string kind()const{return "Account";}double interest()const{return balance_*rate()/100.0;}virtual void print()const{std::cout<<kind()<<' '<<owner_<<" rate="<<rate()<<" interest="<<interest()<<'\n';}};
class SeniorAccount:public Account{std::vector<double> history_;public:SeniorAccount(std::string o,double b):Account(std::move(o),b),history_(100,b){}double rate()const override{return 6.0;}std::string kind()const override{return "SeniorAccount";}};
int main(){std::vector<std::unique_ptr<Account>> accounts;accounts.push_back(std::make_unique<Account>("Asha",10000));accounts.push_back(std::make_unique<SeniorAccount>("Ravi",20000));for(const auto&a:accounts)a->print();Account base=*accounts.front();base.print();}
