#include <iostream>
#include <vector>
struct Cart{int items=0;};int main(){std::vector<Cart> carts;carts.reserve(1);carts.push_back({2});Cart* old=&carts[0];std::cout<<"before growth: "<<old->items<<'\n';carts.push_back({5});std::cout<<"after growth, use carts[0] safely: "<<carts[0].items<<'\n';std::cout<<"A pointer captured before reallocation is invalid; do not dereference it.\n";}
