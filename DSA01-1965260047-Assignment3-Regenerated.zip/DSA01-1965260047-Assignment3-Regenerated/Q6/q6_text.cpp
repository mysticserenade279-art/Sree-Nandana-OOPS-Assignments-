#include <cstring>
#include <iostream>
class Text {
    char* data; int len;
public:
    static int copies;
    Text(const char* s=""):data(new char[std::strlen(s)+1]),len(static_cast<int>(std::strlen(s))){std::memcpy(data,s,len+1);}
    Text(const Text& o):data(new char[o.len+1]),len(o.len){std::memcpy(data,o.data,len+1);++copies;}
    Text& operator=(const Text& o){if(this!=&o){char* fresh=new char[o.len+1];std::memcpy(fresh,o.data,o.len+1);delete[] data;data=fresh;len=o.len;}return *this;}
    ~Text(){delete[] data;}
    friend Text operator+(const Text& a,const Text& b){Text r;delete[] r.data;r.len=a.len+b.len;r.data=new char[r.len+1];std::memcpy(r.data,a.data,a.len);std::memcpy(r.data+a.len,b.data,b.len+1);return r;}
    friend bool operator==(const Text& a,const Text& b){return a.len==b.len&&std::memcmp(a.data,b.data,a.len)==0;}
    friend bool operator!=(const Text& a,const Text& b){return !(a==b);}
    friend std::ostream& operator<<(std::ostream& os,const Text& t){return os<<t.data;}
};
int Text::copies=0;
int main(){Text a("Hello"),b(", "),c("world");Text d=a+b+c;std::cout<<d<<'\n';Text e=d;e=e;std::cout<<std::boolalpha<<(d==e)<<", copies="<<Text::copies<<'\n';}
