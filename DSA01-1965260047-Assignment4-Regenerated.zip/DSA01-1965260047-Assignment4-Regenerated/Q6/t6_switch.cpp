#include <iostream>
enum class Kind{Bike,Motor,Bus};struct Vehicle{Kind kind;double daily,units;double charge()const{switch(kind){case Kind::Bike:return daily+units*.5;case Kind::Motor:return daily+units*4;case Kind::Bus:return daily+units*8;}return 0;}};int main(){Vehicle v{Kind::Motor,1200,30};std::cout<<v.charge()<<'\n';}
