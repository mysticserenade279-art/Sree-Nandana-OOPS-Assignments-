// INTENTIONAL COMPILE-ERROR DEMONSTRATION: ta.name is ambiguous without virtual inheritance.
#include <string>
struct Person{std::string name="Kavya";};struct Student:Person{};struct Staff:Person{};struct TA:Student,Staff{};int main(){TA ta;return ta.name.empty();}
