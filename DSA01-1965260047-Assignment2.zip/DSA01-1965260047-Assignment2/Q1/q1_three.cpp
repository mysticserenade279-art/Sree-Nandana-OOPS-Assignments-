#include <iostream>
#include <string>
struct Student{std::string name;long long fee;char notes[200];};
void byValue(long long f,int p){f-=f*p/100;} void byReference(long long& f,int p){f-=f*p/100;} void byPointer(long long* f,int p){*f-=*f*p/100;}
long long returnNew(long long f,int p){return f-f*p/100;} long long readOnly(const Student&s,int p){return s.fee-s.fee*p/100;}
int main(){long long a=45000,b=45000,c=45000,d=45000;byValue(a,10);byReference(b,10);byPointer(&c,10);d=returnNew(d,10);std::cout<<"by value: "<<a<<"\nby reference: "<<b<<"\nby pointer: "<<c<<"\nreturned: "<<d<<'\n';long long f=45000;f=returnNew(f,10);f=returnNew(f,15);std::cout<<"merit then sports: "<<f<<'\n';Student s{"Asha",45000,{}};std::cout<<"sizeof(long long)="<<sizeof(long long)<<", sizeof(Student)="<<sizeof(Student)<<'\n'<<"const reference result: "<<readOnly(s,10)<<'\n';}
