#include <iostream>
#include <iomanip>
#include <limits>

int main() {
    int zone;
    std::cout << "Enter zone (1-3): ";

    while (!(std::cin >> zone)) {
        std::cout << "Not a number, try again: ";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    if (zone < 1 || zone > 3) {
        std::cout << "Zone not supported\n";
        return 1;
    }

    const long long farePaise = zone * 1000LL;
    std::cout << std::fixed << std::setprecision(2);
    std::cout << "Zone: " << zone << '\n';
    std::cout << "Fare: Rs " << farePaise / 100.0 << '\n';
}
