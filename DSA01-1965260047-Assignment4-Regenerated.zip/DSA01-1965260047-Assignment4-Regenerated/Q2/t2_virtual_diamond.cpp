#include <iostream>
struct Person{Person(){std::cout<<"Person ";}};struct Student:virtual Person{Student(){std::cout<<"Student ";}};struct Staff:virtual Person{Staff(){std::cout<<"Staff ";}};struct TA:Student,Staff{TA(){std::cout<<"TA ";}};int main(){TA t;std::cout<<'\n';}
