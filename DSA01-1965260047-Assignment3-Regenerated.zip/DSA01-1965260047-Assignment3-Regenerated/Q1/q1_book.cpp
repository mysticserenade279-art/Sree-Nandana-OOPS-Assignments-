#include <iostream>
#include <string>
class Book {
    std::string title, author; int copies;
public:
    Book(const std::string& t, const std::string& a, int c)
        : title(t), author(a), copies(c < 0 ? 0 : c) {
        if (c < 0) std::cout << "[warning] negative copies changed to 0\n";
    }
    Book() : Book("Untitled", "Unknown", 0) {}
    explicit Book(const std::string& t) : Book(t, "Unknown", 1) {}
    Book(const std::string& t, int c) : Book(t, "Unknown", c) {}
    void print() const { std::cout << '"' << title << "\" by " << author << ", copies = " << copies << '\n'; }
};
int main() {
    Book a; a.print();
    Book b("Wings of Fire"); b.print();
    Book c("Malgudi Days", 4); c.print();
    Book d("Godan", "Premchand", 7); d.print();
    Book e("Gitanjali", "Tagore", -5); e.print();
}
