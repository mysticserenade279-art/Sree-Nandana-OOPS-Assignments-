#include <iostream>

int main() {
    int p = 17, q = 5;
    double r1 = p / q;  // Integer division happens first.
    double r2 = static_cast<double>(p) / q;

    bool active = -8;
    std::cout << r1 << '\n';
    std::cout << r2 << '\n';
    std::cout << std::boolalpha << active << '\n';

    unsigned int big = 3;
    int neg = -5;
    if (neg < big)
        std::cout << "neg is smaller\n";
    else
        std::cout << "neg is not smaller\n";
}
