#include <iomanip>
#include <iostream>
#include <memory>
#include <string>
#include <vector>
class Vehicle{std::string reg_;double daily_;bool rented_=false;public:Vehicle(std::string r,double d):reg_(std::move(r)),daily_(d){}virtual ~Vehicle()=default;virtual double usageCharge(double units)const=0;virtual std::string kind()const=0;void rent(){if(rented_)throw std::logic_error("already rented");rented_=true;}void giveBack(double days,double units,double lateDays=0){if(!rented_)throw std::logic_error("not rented");double charge=days*daily_+usageCharge(units)+lateDays*daily_*1.25;rented_=false;std::cout<<kind()<<' '<<reg_<<" total Rs "<<charge<<'\n';}};
class Bicycle:public Vehicle{public:using Vehicle::Vehicle;double usageCharge(double km)const override{return km*0.5;}std::string kind()const override{return "Bicycle";}};
class MotorVehicle:public Vehicle{public:using Vehicle::Vehicle;double usageCharge(double km)const override{return km*4.0;}std::string kind()const override{return "MotorVehicle";}};
class ElectricBus:public Vehicle{public:using Vehicle::Vehicle;double usageCharge(double kwh)const override{return kwh*8.0;}std::string kind()const override{return "ElectricBus";}};
int main(){std::vector<std::unique_ptr<Vehicle>> fleet;fleet.push_back(std::make_unique<Bicycle>("B-01",100));fleet.push_back(std::make_unique<MotorVehicle>("M-01",1200));fleet.push_back(std::make_unique<ElectricBus>("E-01",5000));for(auto&v:fleet){v->rent();v->giveBack(2,30,1);}}
