# DSA01-1965260047 — Assignment 3 (CO3)

**Topic:** Constructors, Destructors and Operator Overloading in C++  
**Student:** Sree Nandana K.  
**Register number:** 1965260047

## Contents

| Folder | Topic | Source file |
|---|---|---|
| Q1 | Constructors and constructor overloading | `q1_book.cpp` |
| Q2 | Copy constructors and deep copies | `q2_prescription.cpp` |
| Q3 | Dynamic allocation and destructors | `q3_event.cpp` |
| Q4 | Arithmetic and stream operator overloading | `q4_money.cpp` |
| Q5 | Increment, comparison and subscript operators | `q5_player.cpp` |
| Q6 | Rule of Three and Text operators | `q6_text.cpp` |
| Q7 | Complex-number class and impedance calculator | `q7_complex.cpp` |

## Compile and run

Use a C++17 compiler. From the repository root, compile each source separately:

```bash
g++ -std=c++17 -Wall -Wextra -pedantic Q1/q1_book.cpp -o q1 && ./q1
```

Replace the source path and executable name for Q2–Q7. Each folder contains one standalone program with its own `main()`.

## Validation

The seven included programs were compiled independently using `g++ -std=c++17 -Wall -Wextra -pedantic`. They are illustrative working implementations of the seven assignment topics. Runtime outputs can vary only where the program uses implementation-dependent allocation behaviour; no such behaviour is used in these seven programs.

## GitHub submission reminder

Create the repository named `DSA01-1965260047-Assignment3`, add these folders and this README, then commit the work progressively. Add your own execution screenshots and any additional evidence required by your faculty before submission.
