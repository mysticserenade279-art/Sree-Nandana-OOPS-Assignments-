#include <cmath>
#include <iomanip>
#include <iostream>
#include <stdexcept>
class Complex {
    double re,im;
public:
    Complex():re(0),im(0){} Complex(double r):re(r),im(0){} Complex(double r,double i):re(r),im(i){}
    double magnitude()const{return std::sqrt(re*re+im*im);}
    Complex operator+(const Complex& o)const{return {re+o.re,im+o.im};}
    Complex operator-(const Complex& o)const{return {re-o.re,im-o.im};}
    Complex operator*(const Complex& o)const{return {re*o.re-im*o.im,re*o.im+im*o.re};}
    Complex operator/(const Complex& o)const{double d=o.re*o.re+o.im*o.im;if(d==0)throw std::domain_error("division by zero impedance");return {(re*o.re+im*o.im)/d,(im*o.re-re*o.im)/d};}
    friend std::ostream& operator<<(std::ostream& os,const Complex& z){return os<<std::fixed<<std::setprecision(3)<<z.re<<(z.im<0?" - ":" + ")<<std::fabs(z.im)<<'j';}
};
Complex parallel(const Complex& a,const Complex& b){return (a*b)/(a+b);}
int main(){Complex r(10),l(0,20),c(0,-10);Complex series=r+l+c;std::cout<<"Series Z = "<<series<<", |Z| = "<<series.magnitude()<<'\n';std::cout<<"Parallel R || L = "<<parallel(r,l)<<'\n';try{std::cout<<r/Complex()<<'\n';}catch(const std::domain_error& e){std::cout<<"Error: "<<e.what()<<'\n';}}
