#include <iostream>

// Procedural version
long long proceduralBalance = 9000;

long long tripCost(int zone, bool peak) {
    if (zone < 1 || zone > 3) return -1;
    long long cost = zone * 1000LL;
    if (peak) cost += cost * 20 / 100;
    return cost;
}

bool proceduralDeduct(long long cost) {
    if (cost < 0 || proceduralBalance - cost < 5000) return false;
    proceduralBalance -= cost;
    return true;
}

// Object-oriented version
class MetroCard {
private:
    long long balance;
public:
    explicit MetroCard(long long initialBalance) : balance(initialBalance) {}

    bool canTravel(long long cost) const {
        return cost >= 0 && balance - cost >= 5000;
    }

    bool deduct(long long cost) {
        if (!canTravel(cost)) return false;
        balance -= cost;
        return true;
    }

    long long remaining() const { return balance; }
};

int main() {
    const long long cost = tripCost(2, false);
    if (proceduralDeduct(cost))
        std::cout << "Procedural balance (paise): " << proceduralBalance << '\n';

    MetroCard card(9000);
    if (card.deduct(cost))
        std::cout << "OOP balance (paise): " << card.remaining() << '\n';
}
