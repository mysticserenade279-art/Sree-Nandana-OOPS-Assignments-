#include <iostream>
#include <iomanip>

enum class Zone { Inner = 0, Middle, Outer, Airport };
constexpr long long ZONE_PRICE_PAISE[] = {1000, 2000, 3000, 6000};

long long fareFor(Zone zone, bool peak, bool weekend) {
    const int index = static_cast<int>(zone);
    if (index < 0 || index > 3) return -1;

    long long price = ZONE_PRICE_PAISE[index];
    if (weekend) {
        price -= price / 10;          // 10% weekend discount
    } else if (peak) {
        price += price / 5;           // 20% peak surcharge
    }
    return price;
}

class UnlimitedPass {
private:
    Zone firstZone;
    Zone secondZone;
public:
    UnlimitedPass(Zone first, Zone second)
        : firstZone(first), secondZone(second) {}

    bool covers(Zone zone) const {
        return zone == firstZone || zone == secondZone;
    }
};

int main() {
    std::cout << std::fixed << std::setprecision(2);
    std::cout << "Airport, weekday rush: Rs "
              << fareFor(Zone::Airport, true, false) / 100.0 << '\n';
    std::cout << "Airport, weekend: Rs "
              << fareFor(Zone::Airport, true, true) / 100.0 << '\n';
    std::cout << "Outer, weekday normal: Rs "
              << fareFor(Zone::Outer, false, false) / 100.0 << '\n';

    UnlimitedPass pass(Zone::Middle, Zone::Outer);
    std::cout << "Pass covers Middle: "
              << (pass.covers(Zone::Middle) ? "Yes" : "No") << '\n';
    std::cout << "Pass covers Airport: "
              << (pass.covers(Zone::Airport) ? "Yes" : "No") << '\n';
}
