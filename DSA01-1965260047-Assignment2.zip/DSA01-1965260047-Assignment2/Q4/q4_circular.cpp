#include <iostream>
class History{static constexpr int CAP=10;long long t[CAP]{};int start=0,count=0;public:void add(long long x){if(count<CAP){t[(start+count)%CAP]=x;++count;}else{t[start]=x;start=(start+1)%CAP;}}void print()const{for(int i=0;i<count;++i)std::cout<<t[(start+i)%CAP]<<' ';std::cout<<'\n';}};
int main(){History h;for(int i=1;i<=12;++i)h.add(i*100);h.print();}
