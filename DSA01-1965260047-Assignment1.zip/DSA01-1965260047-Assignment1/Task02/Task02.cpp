#include <iostream>
#include <iomanip>

constexpr long long INNER_FARE_PAISE = 1000;
constexpr long long MIDDLE_FARE_PAISE = 2000;
constexpr long long OUTER_FARE_PAISE = 3000;
constexpr int PEAK_SURCHARGE_PERCENT = 20;
constexpr long long MINIMUM_BALANCE_PAISE = 5000;

enum class Zone { Inner, Middle, Outer };

int main() {
    const Zone selectedZone = Zone::Middle;
    long long fare = MIDDLE_FARE_PAISE;

    if (selectedZone == Zone::Inner) fare = INNER_FARE_PAISE;
    else if (selectedZone == Zone::Outer) fare = OUTER_FARE_PAISE;

    const bool peakHour = true;
    if (peakHour) fare += fare * PEAK_SURCHARGE_PERCENT / 100;

    std::cout << "Fare: Rs " << std::fixed << std::setprecision(2)
              << fare / 100.0 << '\n';
    std::cout << "Minimum remaining balance: Rs "
              << MINIMUM_BALANCE_PAISE / 100.0 << '\n';
}
