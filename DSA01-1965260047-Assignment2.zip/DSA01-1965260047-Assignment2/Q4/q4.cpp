#include <iostream>
class SavingsAccount{static const int MAX=10;long long no,balance,txn[MAX];int count;void record(long long x);public:SavingsAccount(long long n,long long b):no(n),balance(b),txn{},count(0){}long long getBalance()const{return balance;}bool deposit(long long);bool withdraw(long long);void miniStatement()const;};
void SavingsAccount::record(long long x){if(count==MAX){for(int i=1;i<MAX;++i)txn[i-1]=txn[i];count=MAX-1;}txn[count++]=x;}
bool SavingsAccount::deposit(long long x){if(x<=0)return false;balance+=x;record(x);return true;}bool SavingsAccount::withdraw(long long x){if(x<=0||x>balance)return false;balance-=x;record(-x);return true;}
void SavingsAccount::miniStatement()const{std::cout<<"Account "<<no<<" - last "<<count<<" transactions\n";for(int i=0;i<count;++i)std::cout<<(txn[i]>=0?" Deposit ":" Withdrawal ")<<(txn[i]>=0?txn[i]:-txn[i])<<'\n';std::cout<<"Balance: "<<balance<<'\n';}
int main(){SavingsAccount a(1001,5000);for(int i=1;i<=7;++i)a.deposit(i*100);for(int i=1;i<=5;++i)a.withdraw(i*50);a.miniStatement();}
