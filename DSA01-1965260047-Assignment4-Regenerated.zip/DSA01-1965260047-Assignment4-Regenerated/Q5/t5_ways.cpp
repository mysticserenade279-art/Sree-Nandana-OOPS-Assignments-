#include <iostream>
#include <string>
#include <vector>
struct Cart{std::string customer;int items=0;Cart& add(int n){items+=n;return *this;}void show()const{std::cout<<customer<<" items="<<items<<'\n';}};
int main(){Cart c{"Asha"};c.add(2).add(3);Cart* p=&c;Cart& r=c;(*p).show();p->show();r.show();c.show();Cart b{"Ravi"};b.add(1);std::vector<Cart*> active{&c,&b};for(auto q:active)q->show();}
