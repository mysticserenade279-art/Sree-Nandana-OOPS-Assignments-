#include <iostream>
#include <string>
class BusTicket{static int issued;static const int CAPACITY=3;int seat;std::string name;public:explicit BusTicket(const std::string&n):seat(0),name(n){if(issued<CAPACITY)seat=++issued;}static int count(){return issued;}void print()const{std::cout<<name<<": "<<(seat?"Seat "+std::to_string(seat):std::string("Waiting"))<<'\n';}};int BusTicket::issued=0;
void bookTwo(const std::string&a,const std::string&b){BusTicket x(a),y(b);x.print();y.print();std::cout<<"issued so far: "<<BusTicket::count()<<'\n';}
int main(){std::cout<<"Call 1\n";bookTwo("Asha","Bala");std::cout<<"Call 2\n";bookTwo("Chitra","Dev");std::cout<<"Final count: "<<BusTicket::count()<<'\n';}
