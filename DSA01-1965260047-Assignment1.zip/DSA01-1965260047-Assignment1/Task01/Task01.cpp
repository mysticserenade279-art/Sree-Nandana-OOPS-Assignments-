#include <iostream>
#include <string>

// Supporting example for Task 1: identifying objects and their responsibilities.
class Passenger {
public:
    Passenger(std::string passengerName, bool isStudent)
        : name(std::move(passengerName)), student(isStudent) {}

    int concessionPercent() const { return student ? 10 : 0; }
    std::string name;
private:
    bool student;
};

class SmartCard {
public:
    explicit SmartCard(long long startingBalancePaise) : balance(startingBalancePaise) {}

    bool canTravel(long long farePaise) const {
        return farePaise >= 0 && balance - farePaise >= 5000;
    }

    bool deduct(long long farePaise) {
        if (!canTravel(farePaise)) return false;
        balance -= farePaise;
        return true;
    }

    long long getBalance() const { return balance; }
private:
    long long balance;
};

int main() {
    Passenger passenger("Sample Passenger", true);
    SmartCard card(10000);
    const long long farePaise = 2000;

    std::cout << "Passenger: " << passenger.name << '\n';
    std::cout << "Student concession: " << passenger.concessionPercent() << "%\n";
    if (card.deduct(farePaise)) {
        std::cout << "Journey accepted\n";
    } else {
        std::cout << "Journey denied\n";
    }
    std::cout << "Remaining balance: Rs " << card.getBalance() / 100.0 << '\n';
}
