#include <iostream>
#include <climits>
#include <limits>
#include <iomanip>

int main() {
    int hour = 9;
    bool peak = true;
    long long farePaise = 2400;
    long long balancePaise = 10000;
    long long journeys = 3000000;

    std::cout << "sizeof(int): " << sizeof(int) << " bytes\n";
    std::cout << "sizeof(bool): " << sizeof(bool) << " bytes\n";
    std::cout << "sizeof(long long): " << sizeof(long long) << " bytes\n";
    std::cout << "sizeof(double): " << sizeof(double) << " bytes\n";
    std::cout << "INT_MIN: " << INT_MIN << "\nINT_MAX: " << INT_MAX << '\n';
    std::cout << "Hour: " << hour << ", peak: " << std::boolalpha << peak << '\n';
    std::cout << "Fare (paise): " << farePaise
              << ", balance (paise): " << balancePaise << '\n';
    std::cout << "Journey count: " << journeys << '\n';

    double decimalTotal = 0.0;
    long long exactTotalPaise = 0;
    for (int i = 0; i < 1000; ++i) {
        decimalTotal += 0.1;
        exactTotalPaise += 10;
    }
    std::cout << "Repeated double addition (1000 x 0.1): "
              << std::setprecision(17) << decimalTotal << '\n';
    std::cout << "Exact integer-paise total: " << exactTotalPaise << " paise\n";
}
