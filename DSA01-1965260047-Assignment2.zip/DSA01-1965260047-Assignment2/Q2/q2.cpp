#include <iostream>
#include <vector>
int& highest(int a[],int n){int b=0;for(int i=1;i<n;++i)if(a[i]>a[b])b=i;return a[b];}
const int& highestConst(const int a[],int n){int b=0;for(int i=1;i<n;++i)if(a[i]>a[b])b=i;return a[b];}
int highestCopy(const int a[],int n){return highestConst(a,n);}
int main(){int m[]={56,78,91,67,45},n=5;highest(m,n)+=2;std::cout<<"after moderation: ";for(int x:m)std::cout<<x<<' ';std::cout<<'\n';int c=highestCopy(m,n);c+=2;std::cout<<"copy changed to "<<c<<", array still has "<<highestConst(m,n)<<'\n';std::vector<int>v={56,78,91};int* before=&v[0];for(int i=0;i<100;++i)v.push_back(i);std::cout<<"vector storage moved after growing? "<<std::boolalpha<<(before!=&v[0])<<'\n';}
