#include <iostream>
#include <string>
class Prescription {
    int n; std::string* medicines;
public:
    explicit Prescription(int count) : n(count), medicines(new std::string[count > 0 ? count : 0]) {}
    Prescription(const Prescription& o) : n(o.n), medicines(new std::string[o.n]) {
        for (int i = 0; i < n; ++i) medicines[i] = o.medicines[i];
    }
    Prescription& operator=(const Prescription& o) {
        if (this != &o) { auto* fresh = new std::string[o.n]; for (int i=0;i<o.n;++i) fresh[i]=o.medicines[i]; delete[] medicines; medicines=fresh; n=o.n; }
        return *this;
    }
    ~Prescription() { delete[] medicines; }
    void set(int i, const std::string& m) { if (i>=0 && i<n) medicines[i]=m; }
    std::string get(int i) const { return (i>=0 && i<n) ? medicines[i] : ""; }
};
int main() {
    Prescription p(2); p.set(0,"Paracetamol"); p.set(1,"ORS");
    Prescription q=p; q.set(1,"Cetirizine");
    std::cout << "original: " << p.get(0) << ' ' << p.get(1) << '\n';
    std::cout << "copy: " << q.get(0) << ' ' << q.get(1) << '\n';
    p=p; std::cout << "self-assignment safe: " << p.get(0) << '\n';
}
