# Assignment 1 — C++ Programming

**Name:** SREE NANDANA.K  
**Register Number:** 1965260047  
**Course Code:** DSA0101  
**Course Name:** C++ PROGRAMMING

## Repository contents
This repository contains separate folders for Tasks 1–12. Each task folder contains a standalone C++ source file. Task 1 and Task 11 include supporting demonstration programs; Task 10 includes a calculation program to support the required comparison.

## Compiler
Use a C++17-compatible compiler. To check your installed compiler version, run:

```bash
g++ --version
```

Do not write a compiler version here unless you have checked the version on your own computer.

## Compile and run
Open a terminal in the repository folder. For example, to compile Task 6:

```bash
g++ -std=c++17 -Wall -Wextra Task06/Task06.cpp -o task06
```

Run it:

```bash
./task06
```

On Windows, run:

```bash
task06.exe
```

Repeat the same pattern for each task, changing the folder and executable name.

## Task summary
- **Task 01:** Demonstrates Passenger and SmartCard objects, with a private card balance and a minimum-balance check.
- **Task 02:** Demonstrates named `constexpr` fare and balance constants and `enum class`.
- **Task 03:** Prints type sizes and integer limits, and compares repeated decimal addition with integer paise.
- **Task 04:** Demonstrates integer division, `static_cast`, bool conversion and signed/unsigned comparison.
- **Task 05:** Demonstrates operator precedence, increment/decrement, conditional operator, division and remainder.
- **Task 06:** Uses `switch`, peak-hour logic and the Rs 50 minimum remaining-balance rule.
- **Task 07:** Compares a procedural balance with a `MetroCard` class.
- **Task 08:** Validates numeric input and demonstrates recovery using `cin.clear()` and `cin.ignore()`.
- **Task 09:** Runs a fare test table and a five-journey balance demonstration.
- **Task 10:** Compares totals for 20,000, 500,000 and 3,000,000 journeys using integer paise and double rupees.
- **Task 11:** Demonstrates a recommended fare calculation and encapsulated SmartCard.
- **Task 12:** Adds the Airport zone, weekend discount and a two-zone unlimited pass.

## Important notes
1. All fare amounts in the programs are represented as integer paise for exact money calculations, except where conversion to rupees is used only for display.
2. The programs are supporting code for the written assignment. Keep the written explanations, UML diagrams, pseudocode, complexity analysis, test tables and your own execution screenshots in the assignment report as required.
3. Run every program yourself, check its output, and capture screenshots from your compiler/terminal before submission.
4. Commit progressively: make at least one meaningful Git commit for each task. Do not upload all work in one final commit.
5. If the repository is private, add the course faculty as a collaborator.

## Example commit sequence
```bash
git add Task01
git commit -m "Complete Task 1"
git add Task02
git commit -m "Complete Task 2"
```
Continue for each task.
