#include <iostream>
#include <iomanip>
#include <array>

constexpr long long MIN_BALANCE_PAISE = 5000;

bool isPeak(int hour) {
    return (hour >= 8 && hour < 10) || (hour >= 17 && hour < 20);
}

long long calculateFare(int zone, int hour) {
    if (zone < 1 || zone > 3 || hour < 0 || hour > 23) return -1;
    long long fare = zone * 1000LL;
    if (isPeak(hour)) fare += fare * 20 / 100;
    return fare;
}

int main() {
    struct Test { int zone; int hour; long long expected; };
    const std::array<Test, 8> tests{{
        {1, 7, 1000}, {2, 8, 2400}, {3, 19, 3600}, {3, 20, 3000},
        {1, 17, 1200}, {1, 10, 1000}, {2, 20, 2000}, {4, 9, -1}
    }};

    std::cout << "Zone Hour Expected(paise) Actual(paise) Result\n";
    for (const auto& test : tests) {
        const long long actual = calculateFare(test.zone, test.hour);
        std::cout << test.zone << "    " << test.hour << "    "
                  << test.expected << "             " << actual << "          "
                  << (actual == test.expected ? "PASS" : "FAIL") << '\n';
    }

    long long balance = 12000;
    std::cout << "\nFive-journey balance demonstration:\n";
    const int zones[] = {1, 2, 3, 3, 1};
    const int hours[] = {7, 8, 17, 20, 17};
    for (int i = 0; i < 5; ++i) {
        const long long cost = calculateFare(zones[i], hours[i]);
        if (cost >= 0 && balance - cost >= MIN_BALANCE_PAISE) {
            balance -= cost;
            std::cout << "Accepted: Rs " << std::fixed << std::setprecision(2)
                      << cost / 100.0 << '\n';
        } else {
            std::cout << "Denied\n";
        }
    }
    std::cout << "Final balance (paise): " << balance << '\n';
}
