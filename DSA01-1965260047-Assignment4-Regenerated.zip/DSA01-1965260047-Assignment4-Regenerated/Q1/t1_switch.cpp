#include <iostream>
enum class Type{Professor,LabAssistant,Guest};
struct Staff{Type type;double basic=0,research=0,hours=0,rate=0;double pay()const{switch(type){case Type::Professor:return basic*1.42+research;case Type::LabAssistant:return basic*1.42;case Type::Guest:return hours*rate;}return 0;}};
int main(){Staff p{Type::Professor,80000,15000,0,0},l{Type::LabAssistant,30000,0,0,0},g{Type::Guest,0,0,20,1500};std::cout<<p.pay()<<' '<<l.pay()<<' '<<g.pay()<<"\n";}
