// Intentional unsafe example; reference to local variable is dangling.
#include <iostream>
int& badMax(int a,int b){int result=a>b?a:b;return result;}
int main(){int& r=badMax(10,20);std::cout<<r<<'\n';} // undefined behavior
