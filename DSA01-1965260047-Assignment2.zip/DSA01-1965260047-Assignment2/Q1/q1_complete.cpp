#include <iostream>
void applyByValue(long long fee,int p){fee-=fee*p/100;}
void applyConcession(long long& fee,int p){fee-=fee*p/100;}
int main(){long long fee=45000;applyByValue(fee,10);std::cout<<"after call by value : "<<fee<<'\n';applyConcession(fee,10);std::cout<<"after call by reference: "<<fee<<'\n';}
