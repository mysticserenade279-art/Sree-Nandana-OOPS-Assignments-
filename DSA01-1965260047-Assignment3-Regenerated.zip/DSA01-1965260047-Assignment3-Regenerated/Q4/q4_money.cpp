#include <iomanip>
#include <iostream>
class Money {
    long long paise;
public:
    Money(long long rupees=0,int p=0):paise(rupees*100+p){}
    Money& operator+=(const Money& o){paise+=o.paise;return *this;}
    Money& operator-=(const Money& o){paise-=o.paise;return *this;}
    Money operator+(const Money& o)const{Money r=*this;r+=o;return r;}
    Money operator-(const Money& o)const{Money r=*this;r-=o;return r;}
    bool operator==(const Money& o)const{return paise==o.paise;}
    bool operator<(const Money& o)const{return paise<o.paise;}
    friend std::ostream& operator<<(std::ostream& os,const Money& m){long long v=m.paise<0?-m.paise:m.paise;return os<<(m.paise<0?"-":"")<<"Rs "<<v/100<<'.'<<std::setw(2)<<std::setfill('0')<<v%100<<std::setfill(' ');}
};
int main(){Money rice(120,75),oil(79,25),discount(10);Money bill=rice+oil-discount;std::cout<<"Bill: "<<bill<<'\n';std::cout<<std::boolalpha<<(bill==Money(190))<<'\n';}
