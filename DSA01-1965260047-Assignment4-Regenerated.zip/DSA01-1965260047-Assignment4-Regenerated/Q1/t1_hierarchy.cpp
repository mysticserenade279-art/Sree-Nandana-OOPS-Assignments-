#include <iomanip>
#include <iostream>
#include <memory>
#include <string>
#include <vector>
constexpr double DA_PERCENT=42.0;
class Staff { std::string name_; int id_; public: Staff(std::string n,int id):name_(std::move(n)),id_(id){} virtual ~Staff()=default; const std::string& name()const{return name_;} int id()const{return id_;} virtual double pay()const=0; virtual std::string category()const=0; };
class FullTimeStaff:public Staff { protected: double basic_; double basicWithDA()const{return basic_*(1+DA_PERCENT/100.0);} public: FullTimeStaff(std::string n,int id,double b):Staff(std::move(n),id),basic_(b){} };
class Professor:public FullTimeStaff { double research_; public: Professor(std::string n,int id,double b,double r):FullTimeStaff(std::move(n),id,b),research_(r){} double pay()const override{return basicWithDA()+research_;} std::string category()const override{return "Professor";} };
class LabAssistant:public FullTimeStaff { public: using FullTimeStaff::FullTimeStaff; double pay()const override{return basicWithDA();} std::string category()const override{return "Lab Assistant";} };
class GuestFaculty:public Staff { double hours_,rate_; public: GuestFaculty(std::string n,int id,double h,double r):Staff(std::move(n),id),hours_(h),rate_(r){} double pay()const override{return hours_*rate_;} std::string category()const override{return "Guest Faculty";} };
int main(){std::vector<std::unique_ptr<Staff>> v;v.push_back(std::make_unique<Professor>("Dr Meena",101,80000,15000));v.push_back(std::make_unique<LabAssistant>("Ravi",202,30000));v.push_back(std::make_unique<GuestFaculty>("Anitha",303,20,1500));double sum=0;std::cout<<std::fixed<<std::setprecision(2);for(auto& s:v){std::cout<<s->category()<<" | "<<s->name()<<" | Rs "<<s->pay()<<'\n';sum+=s->pay();}std::cout<<"Payroll total: Rs "<<sum<<'\n';}
