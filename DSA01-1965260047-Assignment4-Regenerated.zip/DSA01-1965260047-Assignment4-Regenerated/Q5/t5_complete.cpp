#include <iostream>
struct Counter{int value=0;Counter& add(int n){value+=n;return *this;}Counter& reset(){value=0;return *this;}void show()const{std::cout<<value<<'\n';}};int main(){Counter c;c.add(4).add(6).show();c.reset().show();}
