#include <iostream>
struct Base{virtual ~Base(){std::cout<<"~Base ";}virtual void f()const{std::cout<<"Base ";}};struct Derived:Base{~Derived()override{std::cout<<"~Derived ";}void f()const override{std::cout<<"Derived ";}};int main(){Base* p=new Derived;p->f();delete p;std::cout<<'\n';}
