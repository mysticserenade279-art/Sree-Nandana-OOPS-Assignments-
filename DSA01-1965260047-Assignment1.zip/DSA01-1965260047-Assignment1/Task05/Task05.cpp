#include <iostream>

int main() {
    int m = 6, n = 4;

    std::cout << m * n + 3 << ' ' << m * (n + 3) << '\n';

    int w = m-- + 3 * n;
    std::cout << w << ' ' << m << '\n';

    std::cout << (m < n ? m : n) << ' '
              << (w % 5) * 3 << '\n';

    std::cout << 17 / 5 << ' ' << 17 % 5 << ' '
              << -17 / 5 << ' ' << -17 % 5 << '\n';

    int total = 0;
    for (int j = 1; j <= 12; j += 4)
        total += j * 2;
    std::cout << total << '\n';
}
