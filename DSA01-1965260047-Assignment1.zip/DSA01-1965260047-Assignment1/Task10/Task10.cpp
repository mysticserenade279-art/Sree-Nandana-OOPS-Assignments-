#include <iostream>
#include <iomanip>
#include <climits>

int main() {
    // A fixed fare of Rs 24.00 (2400 paise) is used for each sample journey.
    const long long farePaise = 2400;
    const double fareRupees = 24.0;
    const long long journeyCounts[] = {20000, 500000, 3000000};

    std::cout << std::fixed << std::setprecision(2);
    for (long long count : journeyCounts) {
        const long long exactPaise = count * farePaise;
        const double doubleRupees = count * fareRupees;
        const long long totalRupees = exactPaise / 100;

        std::cout << "Journeys: " << count << '\n';
        std::cout << "Integer-paise total: Rs " << totalRupees << '\n';
        std::cout << "Double total: Rs " << doubleRupees << '\n';
        std::cout << "Fits in int (rupees): "
                  << (totalRupees <= INT_MAX ? "Yes" : "No") << "\n\n";
    }

    // Avoid signed int overflow: test the range before converting.
    const long long networkTotalRupees = 3000000LL * 24;
    std::cout << "INT_MAX: " << INT_MAX << '\n';
    std::cout << "Network total in rupees: " << networkTotalRupees << '\n';
    std::cout << "An int can hold this total: "
              << (networkTotalRupees <= INT_MAX ? "Yes" : "No") << '\n';
}
