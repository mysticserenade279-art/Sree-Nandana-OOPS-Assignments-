#include <iostream>
struct Parcel{double kg;bool fragile;};
constexpr long long RATE=4000,EXPRESS=5000,INSURANCE=1000,FRAGILE=2000;
long long options(long long b,bool e,bool i){if(e)b+=EXPRESS;if(i)b+=INSURANCE;return b;}
long long charge(int grams,bool e=false,bool i=false){std::cout<<"[grams] ";return options((long long)grams*RATE/1000,e,i);}
long long charge(double kg,bool e=false,bool i=false){std::cout<<"[kg] ";return options((long long)(kg*RATE),e,i);}
long long charge(const Parcel&p,bool e=false,bool i=false){std::cout<<"[parcel] ";return options((long long)(p.kg*RATE)+(p.fragile?FRAGILE:0),e,i);}
int main(){Parcel p{2.5,true};std::cout<<charge(2)<<'\n'<<charge(2.0f)<<'\n'<<charge(2.5)<<'\n'<<charge(1500,true)<<'\n'<<charge(2.5,true,true)<<'\n'<<charge(p)<<'\n';}
