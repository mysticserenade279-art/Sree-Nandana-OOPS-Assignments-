#include <iostream>
int highestIndex(const int a[],int n){int b=0;for(int i=1;i<n;++i)if(a[i]>a[b])b=i;return b;}
int main(){int m[]={56,78,91,67,45};int i=highestIndex(m,5);m[i]+=2;std::cout<<m[i]<<'\n';}
