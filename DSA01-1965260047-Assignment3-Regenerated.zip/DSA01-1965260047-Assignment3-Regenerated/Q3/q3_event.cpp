#include <iostream>
#include <stdexcept>
#include <string>
class Event {
    std::string name; int rows, cols, booked; char** seats;
public:
    Event(const std::string& n,int r,int c):name(n),rows(r),cols(c),booked(0),seats(nullptr) {
        if (r<0 || c<0) throw std::invalid_argument("negative seat-map size");
        seats = rows ? new char*[rows]{} : nullptr;
        try { for(int i=0;i<rows;++i){ seats[i]=new char[cols]; for(int j=0;j<cols;++j) seats[i][j]='.'; } }
        catch(...) { for(int i=0;i<rows;++i) delete[] seats[i]; delete[] seats; throw; }
        std::cout << "Created " << name << " (" << rows << 'x' << cols << ")\n";
    }
    Event(const Event&)=delete; Event& operator=(const Event&)=delete;
    bool book(int r,int c){ if(r<0||r>=rows||c<0||c>=cols||seats[r][c]=='X') return false; seats[r][c]='X'; ++booked; return true; }
    ~Event(){ for(int i=0;i<rows;++i) delete[] seats[i]; delete[] seats; std::cout<<"Closed "<<name<<", booked="<<booked<<'\n'; }
};
int main(){ Event e("Tech Fest",3,4); e.book(0,1); e.book(2,3); std::cout << std::boolalpha << e.book(0,1) << '\n'; }
