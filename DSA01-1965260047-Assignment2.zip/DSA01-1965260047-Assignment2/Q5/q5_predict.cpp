#include <iostream>
class Token{static int next;int id;public:Token():id(++next){}int get()const{return id;}static int issued(){return next-100;}};int Token::next=100;
int main(){Token a[3],b;std::cout<<a[0].get()<<' '<<a[2].get()<<' '<<b.get()<<' '<<Token::issued()<<'\n';}
